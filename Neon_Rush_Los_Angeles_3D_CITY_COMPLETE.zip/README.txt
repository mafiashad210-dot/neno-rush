NEON RUSH 3D — ULTIMATE V4

Mobile/browser racing edition.

New V4 systems:
- XP + levels + rewards
- dynamic mission HUD
- near-miss XP combo system
- neon rain / clear / storm weather cycle (press M on keyboard)
- dynamic day/night atmosphere
- mobile-first ultimate HUD
- preserves the previous cyberpunk menu, garage, nitro, AI, driver and camera systems

Run by uploading the folder/ZIP to Netlify, GitHub Pages, or another static web host.
Internet is required because Three.js is loaded from CDN.


FIXED BUILD: menu touch navigation and initialization robustness repaired for iPhone/Safari.
